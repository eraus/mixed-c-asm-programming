int mp_str2upper(char *str) {
    int num_cvted = 0;
    while (1) {
        char ch = *str++;
        if (ch == 0) {
            break;
        } else if ((ch >= 'a') && (ch <= 'z')) {
            *(str-1) -= 32;
            num_cvted++;
        }
    }
    return num_cvted;
}
