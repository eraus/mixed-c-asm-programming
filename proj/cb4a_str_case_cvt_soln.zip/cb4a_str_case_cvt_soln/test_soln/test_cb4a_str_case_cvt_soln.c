#include <string.h>
#include "unity.h"
#include "cb4a_str_case_cvt_fns.h"

void test_mp_str2lower_s(void) {
    char str_act[] = "abcxyz6.ABYZ4";
    char str_exp[] = "abcxyz6.abyz4";

    int num_cvted_exp = 4;

    int num_cvted_act = mp_str2lower_s(str_act);

    TEST_ASSERT_EQUAL_UINT8_ARRAY(str_exp, str_act, strlen(str_act));
    TEST_ASSERT_EQUAL_INT32(num_cvted_exp, num_cvted_act);
}
