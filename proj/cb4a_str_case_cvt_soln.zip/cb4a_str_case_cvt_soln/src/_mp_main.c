void mp_main(void) {
#if defined(UNIT_TEST)
    void mp_unity(void);
    mp_unity();
#else
    void mp_app(void);
    mp_app();
#endif
}
