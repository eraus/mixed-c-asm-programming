#pragma once

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include "mp_supported_mcu.h"

extern UART_HandleTypeDef huart2;

#ifdef __GNUC__
    // With GCC, small printf calls __io_putchar()
    // (option LD Linker->Libraries->Small printf set to 'Yes')
    #define PUTCHAR_PROTOTYPE int __io_putchar(int ch)
    #define GETCHAR_PROTOTYPE int __io_getchar(void)
    #define SET_STDIN_TO_NO_BUFFER setvbuf(stdin, NULL, _IONBF, 0)
    /* See:
     * https://forum.digikey.com/t/easily-use-scanf-on-stm32/21103
     * https://www.tutorialspoint.com/c_standard_library/c_function_setvbuf.htm
     */
#else
    #define PUTCHAR_PROTOTYPE int fputc(int ch, FILE *f)
    #define GETCHAR_PROTOTYPE int fgetc(FILE *f)
    #define SET_STDIN_TO_NO_BUFFER {}
#endif /* __GNUC__ */

#ifdef __cplusplus
}
#endif /* __cplusplus */
