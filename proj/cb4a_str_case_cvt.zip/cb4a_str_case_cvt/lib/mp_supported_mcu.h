#pragma once

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include <stdio.h>
#if defined(STM32F412Zx)
    #include "stm32f4xx_hal.h" 
#elif defined(STM32G431xx) 
    #include "stm32g4xx_hal.h"
#elif defined(STM32L476xx) || defined(STM32L432xx)
    #include "stm32l4xx_hal.h" 
#endif

#ifdef __cplusplus
}
#endif /* __cplusplus */
