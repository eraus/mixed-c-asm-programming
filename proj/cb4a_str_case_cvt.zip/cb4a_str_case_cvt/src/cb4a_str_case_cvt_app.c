#include <stdio.h>
#include "mp_supported_mcu.h"
#include "mp_uart_redirect.h"
#include "cb4a_str_case_cvt_fns.h"

void mp_app(void) {
#if defined(SOLN)
    printf("\nRunning SOLUTION version of cb4a main App:\n");
#else
    printf("\nRunning cb4a main App:\n");
#endif

    char str[] = "Hello World!";

    printf("%s\n", str);

    mp_str2upper(str);
    printf("=> %s // converted by C\n", str);

    mp_str2lower_s(str);
    printf("=> %s // converted by asm\n", str);

    while (1);
}
