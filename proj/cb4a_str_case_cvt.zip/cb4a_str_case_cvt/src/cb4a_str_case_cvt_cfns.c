__attribute__((weak))
int mp_str2upper(char *str) {

    return 0;
}
