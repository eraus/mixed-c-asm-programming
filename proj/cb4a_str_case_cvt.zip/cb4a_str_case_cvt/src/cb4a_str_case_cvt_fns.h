#pragma once

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

int mp_str2upper(char *str);
int mp_str2lower_s(char *str);

#ifdef __cplusplus
}
#endif /* __cplusplus */
