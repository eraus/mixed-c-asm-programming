#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include "unity.h"
#include "cb4a_str_case_cvt_fns.h"


void test_mp_str2upper(void) {
    char str_act[] = "abcxyz6.ABYZ4";
    char str_exp[] = "ABCXYZ6.ABYZ4";

    int num_cvted_exp = 6;

    int num_cvted_act = mp_str2upper(str_act);

    TEST_ASSERT_EQUAL_UINT8_ARRAY(str_exp, str_act, strlen(str_act));
    TEST_ASSERT_EQUAL_INT32(num_cvted_exp, num_cvted_act);
}

void test_mp_str2lower_s(void);


void mp_unity(void) {
#if defined(SOLN)
    printf("\nRunning SOLUTION version of cb4a unit test:\n");
#else
    printf("\nRunning cb4a unit test:\n");
#endif

    UNITY_BEGIN();

    RUN_TEST(test_mp_str2upper);
    RUN_TEST(test_mp_str2lower_s);

    UNITY_END();

    while (1);
}


__attribute__((weak))
void test_mp_str2lower_s(void) {
    char str_act[] = "abcxyz6.ABYZ4";
    char str_exp[] = "ABCXYZ6.ABYZ4";

    int num_cvted_exp = 6;

    int num_cvted_act = mp_str2lower_s(str_act);

    TEST_ASSERT_EQUAL_UINT8_ARRAY(str_exp, str_act, strlen(str_act));
    TEST_ASSERT_EQUAL_INT32(num_cvted_exp, num_cvted_act);
}
