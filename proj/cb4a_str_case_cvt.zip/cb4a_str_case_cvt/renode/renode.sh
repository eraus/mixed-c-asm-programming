#!/usr/bin/bash
sh /Applications/Renode.app/Contents/MacOS/macos_run.command
